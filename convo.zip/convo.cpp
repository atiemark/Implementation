#include "src/Convo.h"
#include <iostream>
#include "sdl\sdl.h"
#undef main


int main()
{
    Convo convo;
    convo.Run();

    return 0;
}
