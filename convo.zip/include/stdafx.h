#pragma once

constexpr float PI = 3.141592653589793238462643383279502884f;
constexpr unsigned int SAMPLES = 65536;
